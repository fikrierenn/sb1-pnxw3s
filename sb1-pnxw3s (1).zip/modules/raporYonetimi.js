export class RaporYonetimi {
    constructor(hareketler) {
        this.hareketler = hareketler;
    }

    dukkanOzetiHazirla() {
        const dukkanlar = new Map();

        this.hareketler.forEach((hareket) => {
            if (!dukkanlar.has(hareket.halNo)) {
                dukkanlar.set(hareket.halNo, {
                    halNo: hareket.halNo,
                    toplamGiris: 0,
                    toplamCikis: 0,
                    kalanKasa: 0,
                    rehinTutar: 0,
                });
            }

            const dukkan = dukkanlar.get(hareket.halNo);
            if (hareket.isGiris) {
                dukkan.toplamGiris += hareket.kasaAdet;
                dukkan.kalanKasa += hareket.kasaAdet;
            } else {
                dukkan.toplamCikis += hareket.kasaAdet;
                dukkan.kalanKasa -= hareket.kasaAdet;
            }
            dukkan.rehinTutar += hareket.rehinTutar;
        });

        return Array.from(dukkanlar.values()).sort((a, b) =>
            a.halNo.localeCompare(b.halNo)
        );
    }
}