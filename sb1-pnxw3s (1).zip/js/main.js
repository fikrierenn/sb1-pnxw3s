import { VeriYonetimi } from './modules/veriYonetimi.js';
import { IstatistikYonetimi } from './modules/istatistikYonetimi.js';
import { ArayuzYonetimi } from './modules/arayuzYonetimi.js';
import { RaporYonetimi } from './modules/raporYonetimi.js';

class Dashboard {
    constructor() {
        this.veriYonetimi = new VeriYonetimi();
        this.arayuzYonetimi = new ArayuzYonetimi();
        this.tabloGovdesi = document.querySelector('#transactionsTable tbody');
        this.raporButonu = document.getElementById('showStoreReport');
    }

    async baslat() {
        try {
            const hareketler = await this.veriYonetimi.veriGetir();
            this.istatistikYonetimi = new IstatistikYonetimi(hareketler);
            this.raporYonetimi = new RaporYonetimi(hareketler);
            
            this.dashboardGuncelle();
            this.raporButonuDinleyicisiEkle();
            setInterval(() => this.dashboardGuncelle(), 300000);
        } catch (hata) {
            console.error('Dashboard yüklenirken hata:', hata);
        }
    }

    raporButonuDinleyicisiEkle() {
        if (this.raporButonu) {
            this.raporButonu.addEventListener('click', () => {
                const dukkanOzeti = this.raporYonetimi.dukkanOzetiHazirla();
                const raporPenceresi = window.open('/store-report.html', '_blank');
                
                if (raporPenceresi) {
                    raporPenceresi.addEventListener('load', () => {
                        raporPenceresi.postMessage({ tip: 'dukkanRaporu', veri: dukkanOzeti }, '*');
                    });
                }
            });
        }
    }

    dashboardGuncelle() {
        const bugun = new Date().toISOString().split('T')[0];
        const gunluk = this.istatistikYonetimi.hesaplaGunluk(bugun);
        const genel = this.istatistikYonetimi.hesaplaGenel();
        
        this.arayuzYonetimi.istatistikleriGuncelle(gunluk, genel);
        this.gunlukTabloGuncelle(bugun);
    }

    gunlukTabloGuncelle(tarih) {
        const gunlukHareketler = this.veriYonetimi.hareketleriFiltrele(tarih);
        this.arayuzYonetimi.tabloGuncelle(gunlukHareketler);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const dashboard = new Dashboard();
    dashboard.baslat();
});