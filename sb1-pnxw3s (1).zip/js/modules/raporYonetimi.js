export class RaporYonetimi {
    constructor(hareketler) {
        this.hareketler = hareketler;
    }

    dukkanOzetiHazirla(sifirDegerleriGoster = false) {
        const dukkanlar = new Map();

        this.hareketler.forEach((hareket) => {
            if (!dukkanlar.has(hareket.halNo)) {
                dukkanlar.set(hareket.halNo, {
                    halNo: hareket.halNo,
                    toplamGiris: 0,
                    toplamCikis: 0,
                    kalanKasa: 0,
                    rehinTutar: 0,
                });
            }

            const dukkan = dukkanlar.get(hareket.halNo);
            if (hareket.isGiris) {
                dukkan.toplamGiris += hareket.kasaAdet;
                dukkan.kalanKasa += hareket.kasaAdet;
            } else {
                dukkan.toplamCikis += hareket.kasaAdet;
                dukkan.kalanKasa -= hareket.kasaAdet;
            }
            dukkan.rehinTutar += hareket.rehinTutar;
        });

        let dukkanListesi = Array.from(dukkanlar.values());
        
        // Sıfır değerleri gösterme seçeneğine göre filtrele
        if (!sifirDegerleriGoster) {
            dukkanListesi = dukkanListesi.filter(dukkan => 
                dukkan.kalanKasa !== 0 || dukkan.rehinTutar > 0
            );
        }

        // Akıllı sıralama: Önce sayısal, sonra alfabetik
        return dukkanListesi.sort((a, b) => {
            const numA = parseInt(a.halNo);
            const numB = parseInt(b.halNo);
            
            if (!isNaN(numA) && !isNaN(numB)) {
                return numA - numB;
            }
            
            return a.halNo.localeCompare(b.halNo, 'tr', { numeric: true });
        });
    }
}