import { VeriYonetimi } from './modules/veriYonetimi.js';
import { RaporYonetimi } from './modules/raporYonetimi.js';
import { ArayuzYonetimi } from './modules/arayuzYonetimi.js';

class RaporlarUygulamasi {
    constructor() {
        this.veriYonetimi = new VeriYonetimi();
        this.arayuzYonetimi = new ArayuzYonetimi();
        this.raporFiltreler = document.getElementById('dateReportFilters');
        this.raporSonuclar = document.getElementById('dateReportResults');
        this.storeReportSection = document.getElementById('storeReportSection');
        this.showZeroValues = document.getElementById('showZeroValues');
        this.dukkanlar = [];
        this.toplamlar = {
            giris: 0,
            cikis: 0,
            kalan: 0,
            rehin: 0
        };
        this.siralama = {
            kolon: 'halNo',
            artan: true
        };
    }

    async baslat() {
        try {
            const hareketler = await this.veriYonetimi.veriGetir();
            this.raporYonetimi = new RaporYonetimi(hareketler);
            
            this.raporDinleyicileriniEkle();
            this.filtreDinleyicileriniEkle();
            this.siralamaBasliklariniEkle();
        } catch (hata) {
            console.error('Raporlar yüklenirken hata:', hata);
        }
    }

    siralamaBasliklariniEkle() {
        const basliklar = document.querySelectorAll('#storeReportTable th');
        basliklar.forEach(baslik => {
            const kolonAdi = baslik.getAttribute('data-sort');
            if (kolonAdi) {
                baslik.style.cursor = 'pointer';
                baslik.addEventListener('click', () => this.listeyiSirala(kolonAdi));
                
                // Sıralama oku için span ekle
                const arrow = document.createElement('span');
                arrow.className = 'ms-1';
                baslik.appendChild(arrow);
            }
        });
    }

    listeyiSirala(kolon) {
        if (this.siralama.kolon === kolon) {
            this.siralama.artan = !this.siralama.artan;
        } else {
            this.siralama.kolon = kolon;
            this.siralama.artan = true;
        }

        this.dukkanlar.sort((a, b) => {
            let degerA = a[kolon];
            let degerB = b[kolon];

            // Sayısal sıralama için
            if (typeof degerA === 'number' && typeof degerB === 'number') {
                return this.siralama.artan ? degerA - degerB : degerB - degerA;
            }

            // Hal numarası için özel sıralama
            if (kolon === 'halNo') {
                const numA = parseInt(degerA);
                const numB = parseInt(degerB);
                
                if (!isNaN(numA) && !isNaN(numB)) {
                    return this.siralama.artan ? numA - numB : numB - numA;
                }
            }

            // Metin sıralaması için
            return this.siralama.artan 
                ? degerA.toString().localeCompare(degerB.toString(), 'tr')
                : degerB.toString().localeCompare(degerA.toString(), 'tr');
        });

        this.siralamaBelirtecleriniGuncelle();
        this.tabloIceriginiGuncelle();
    }

    siralamaBelirtecleriniGuncelle() {
        const basliklar = document.querySelectorAll('#storeReportTable th');
        basliklar.forEach(baslik => {
            const kolonAdi = baslik.getAttribute('data-sort');
            const arrow = baslik.querySelector('span');
            if (arrow) {
                if (kolonAdi === this.siralama.kolon) {
                    arrow.textContent = this.siralama.artan ? ' ↑' : ' ↓';
                } else {
                    arrow.textContent = '';
                }
            }
        });
    }

    tabloIceriginiGuncelle() {
        const tbody = document.getElementById('storeReportTable');
        if (tbody) {
            tbody.innerHTML = this.dukkanlar.map(dukkan => `
                <tr>
                    <td>${dukkan.halNo}</td>
                    <td>${dukkan.toplamGiris.toLocaleString('tr-TR')}</td>
                    <td>${dukkan.toplamCikis.toLocaleString('tr-TR')}</td>
                    <td>${dukkan.kalanKasa.toLocaleString('tr-TR')}</td>
                    <td>₺${dukkan.rehinTutar.toLocaleString('tr-TR')}</td>
                </tr>
            `).join('');
        }
    }

    raporDinleyicileriniEkle() {
        const storeReportBtn = document.getElementById('showStoreReport');
        const dateReportBtn = document.getElementById('showDateReport');

        if (storeReportBtn) {
            storeReportBtn.addEventListener('click', () => {
                this.storeReportSection.style.display = 'block';
                this.raporFiltreler.style.display = 'none';
                this.raporSonuclar.style.display = 'none';
                this.dukkanOzetiniGoster();
            });
        }

        if (dateReportBtn) {
            dateReportBtn.addEventListener('click', () => {
                this.storeReportSection.style.display = 'none';
                this.raporFiltreler.style.display = 'block';
                this.raporSonuclar.style.display = 'block';
                this.filtreliRaporGoster();
            });
        }

        if (this.showZeroValues) {
            this.showZeroValues.addEventListener('change', () => {
                this.dukkanOzetiniGoster();
            });
        }
    }

    filtreDinleyicileriniEkle() {
        const startDate = document.getElementById('startDate');
        const endDate = document.getElementById('endDate');
        const halNoFilter = document.getElementById('halNoFilter');

        const filtreHandler = () => this.filtreliRaporGoster();

        if (startDate) startDate.addEventListener('change', filtreHandler);
        if (endDate) endDate.addEventListener('change', filtreHandler);
        if (halNoFilter) halNoFilter.addEventListener('input', filtreHandler);
    }

    toplamlarHesapla() {
        this.toplamlar = {
            giris: 0,
            cikis: 0,
            kalan: 0,
            rehin: 0
        };

        this.dukkanlar.forEach(dukkan => {
            this.toplamlar.giris += dukkan.toplamGiris;
            this.toplamlar.cikis += dukkan.toplamCikis;
            this.toplamlar.kalan += dukkan.kalanKasa;
            this.toplamlar.rehin += dukkan.rehinTutar;
        });
    }

    toplamlarGuncelle() {
        document.getElementById('totalStoreIn').textContent = this.toplamlar.giris.toLocaleString('tr-TR');
        document.getElementById('totalStoreOut').textContent = this.toplamlar.cikis.toLocaleString('tr-TR');
        document.getElementById('totalStoreNet').textContent = this.toplamlar.kalan.toLocaleString('tr-TR');
        document.getElementById('totalStorePledge').textContent = `₺${this.toplamlar.rehin.toLocaleString('tr-TR')}`;
    }

    dukkanOzetiniGoster() {
        const sifirDegerleriGoster = this.showZeroValues.checked;
        this.dukkanlar = this.raporYonetimi.dukkanOzetiHazirla(sifirDegerleriGoster);
        this.toplamlarHesapla();
        this.tabloIceriginiGuncelle();
        this.toplamlarGuncelle();
    }

    filtreliRaporGoster() {
        const startDate = document.getElementById('startDate').value;
        const endDate = document.getElementById('endDate').value;
        const halNo = document.getElementById('halNoFilter').value;

        const filtrelenmisHareketler = this.veriYonetimi.hareketleriFiltreleTarihAralik(
            startDate, 
            endDate, 
            halNo
        );

        const tbody = document.querySelector('#filteredTransactionsTable tbody');
        if (tbody) {
            tbody.innerHTML = filtrelenmisHareketler
                .sort((a, b) => b.tarihObj - a.tarihObj)
                .map(hareket => `
                    <tr>
                        <td>${hareket.halNo}</td>
                        <td>${hareket.islemTuru}</td>
                        <td>${hareket.kasaAdet.toLocaleString('tr-TR')}</td>
                        <td>${this.arayuzYonetimi.tarihFormatla(hareket.tarihObj)}</td>
                        <td>₺${hareket.rehinTutar.toLocaleString('tr-TR')}</td>
                    </tr>
                `).join('');
        }
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const raporlarUygulamasi = new RaporlarUygulamasi();
    raporlarUygulamasi.baslat();
});